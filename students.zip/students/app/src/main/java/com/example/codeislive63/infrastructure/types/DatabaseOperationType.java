package com.example.codeislive63.infrastructure.types;

public enum DatabaseOperationType {
    Insert,
    Update,
    Delete
}